# Hitbox Visual (Fabric 1.20.1)
Client-side. Requer Fabric Loader >= 0.14.21 e Fabric API.

## Compilar
Java 17 + Gradle 8.5+ (com internet na 1ª vez):
    gradle wrapper --gradle-version 8.5
    ./gradlew build        (Windows: gradlew.bat build)
O .jar fica em build/libs/hitboxvisual-1.0.0.jar (não use o -sources.jar).

## Teclas (Controles > Hitbox Visual)
H = ligar/desligar hitboxes | J = abrir configurações
Config: config/hitboxvisual.json
