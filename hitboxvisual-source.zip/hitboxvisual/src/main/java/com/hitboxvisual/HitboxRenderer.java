package com.hitboxvisual;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Renderiza hitboxes preenchidas (translúcidas) + contorno com espessura real (caixas finas),
 * sem usar glLineWidth (que é limitado em GL ES / GL4ES usado por launchers Android).
 * Tudo é enviado em UM único draw call por frame.
 */
public final class HitboxRenderer {
    private static final List<Entity> ENTITIES = new ArrayList<>();
    private static final List<Box> BOXES = new ArrayList<>();

    private HitboxRenderer() {}

    public static void render(WorldRenderContext ctx) {
        HitboxConfig cfg = HitboxConfig.get();
        if (!cfg.enabled || !cfg.showHitboxes) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = ctx.world();
        if (world == null || mc.player == null) return;

        Camera camera = ctx.camera();
        Vec3d camPos = camera.getPos();
        float td = ctx.tickDelta();
        double maxSq = (double) cfg.maxDistance * cfg.maxDistance;

        ENTITIES.clear();
        BOXES.clear();

        for (Entity e : world.getEntities()) {
            if (!accept(e, cfg, mc, camera)) continue;
            if (e.squaredDistanceTo(camPos) > maxSq) continue;

            // Interpola a posição igual ao renderer vanilla -> hitbox acompanha o modelo sem atraso.
            double dx = MathHelper.lerp(td, e.lastRenderX, e.getX()) - e.getX();
            double dy = MathHelper.lerp(td, e.lastRenderY, e.getY()) - e.getY();
            double dz = MathHelper.lerp(td, e.lastRenderZ, e.getZ()) - e.getZ();
            Box box = e.getBoundingBox().offset(dx, dy, dz).expand(e.getTargetingMargin());

            ENTITIES.add(e);
            BOXES.add(box);
        }
        if (BOXES.isEmpty()) return;

        int target = findTarget(world, mc, camera, cfg);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        if (cfg.seeThroughWalls) RenderSystem.disableDepthTest();

        Matrix4f m = ctx.matrixStack().peek().getPositionMatrix();
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();
        buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

        float baseHalf = cfg.outlineThickness * 0.0025f;

        // Passo 1: preenchimentos
        for (int i = 0; i < BOXES.size(); i++) {
            boolean aimed = i == target;
            int rgb = aimed ? cfg.aimColor : cfg.normalColor;
            float a = aimed ? cfg.aimFillAlpha : cfg.fillAlpha;
            if (a <= 0f) continue;
            Box b = BOXES.get(i);
            addBox(buf, m,
                    (float) (b.minX - camPos.x), (float) (b.minY - camPos.y), (float) (b.minZ - camPos.z),
                    (float) (b.maxX - camPos.x), (float) (b.maxY - camPos.y), (float) (b.maxZ - camPos.z),
                    r(rgb), g(rgb), bl(rgb), a);
        }

        // Passo 2: contornos (por cima do preenchimento)
        for (int i = 0; i < BOXES.size(); i++) {
            boolean aimed = i == target;
            int rgb = aimed ? cfg.aimColor : cfg.normalColor;
            float h = aimed ? baseHalf * 1.6f : baseHalf; // contorno destacado quando na mira
            Box b = BOXES.get(i);
            addOutline(buf, m,
                    (float) (b.minX - camPos.x), (float) (b.minY - camPos.y), (float) (b.minZ - camPos.z),
                    (float) (b.maxX - camPos.x), (float) (b.maxY - camPos.y), (float) (b.maxZ - camPos.z),
                    h, r(rgb), g(rgb), bl(rgb), 1.0f);
        }

        tess.draw();

        if (cfg.seeThroughWalls) RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static boolean accept(Entity e, HitboxConfig cfg, MinecraftClient mc, Camera camera) {
        if (e.isSpectator()) return false;
        if (e == mc.player) return cfg.showSelf && camera.isThirdPerson();
        if (e instanceof PlayerEntity) return cfg.players;
        if (!(e instanceof LivingEntity)) return false;
        if (e instanceof Monster) return cfg.hostile;
        if (e instanceof PassiveEntity) return cfg.passive;
        return cfg.otherLiving;
    }

    /** Raycast a partir da câmera na direção da mira. Retorna índice da hitbox apontada ou -1. */
    private static int findTarget(ClientWorld world, MinecraftClient mc, Camera camera, HitboxConfig cfg) {
        Vec3d start = camera.getPos();
        Vec3d dir = Vec3d.fromPolar(camera.getPitch(), camera.getYaw());
        Vec3d end = start.add(dir.multiply(cfg.maxDistance));

        int best = -1;
        double bestDist = Double.MAX_VALUE;
        Vec3d bestHit = null;
        for (int i = 0; i < BOXES.size(); i++) {
            if (ENTITIES.get(i) == mc.player) continue;
            Optional<Vec3d> hit = BOXES.get(i).raycast(start, end);
            if (hit.isPresent()) {
                double d = hit.get().squaredDistanceTo(start);
                if (d < bestDist) {
                    bestDist = d;
                    best = i;
                    bestHit = hit.get();
                }
            }
        }
        if (best < 0) return -1;

        // Blocos sólidos na frente bloqueiam a mira
        HitResult block = world.raycast(new RaycastContext(start, bestHit,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return block.getType() == HitResult.Type.MISS ? best : -1;
    }

    private static void addOutline(BufferBuilder buf, Matrix4f m,
                                   float x1, float y1, float z1, float x2, float y2, float z2,
                                   float h, float r, float g, float b, float a) {
        float[] ys = {y1, y2};
        float[] zs = {z1, z2};
        float[] xs = {x1, x2};
        for (float y : ys) for (float z : zs)
            addBox(buf, m, x1 - h, y - h, z - h, x2 + h, y + h, z + h, r, g, b, a);   // arestas em X
        for (float x : xs) for (float z : zs)
            addBox(buf, m, x - h, y1 - h, z - h, x + h, y2 + h, z + h, r, g, b, a);   // arestas em Y
        for (float x : xs) for (float y : ys)
            addBox(buf, m, x - h, y - h, z1 - h, x + h, y + h, z2 + h, r, g, b, a);   // arestas em Z
    }

    private static void addBox(BufferBuilder buf, Matrix4f m,
                               float x1, float y1, float z1, float x2, float y2, float z2,
                               float r, float g, float b, float a) {
        // baixo
        v(buf, m, x1, y1, z1, r, g, b, a); v(buf, m, x2, y1, z1, r, g, b, a);
        v(buf, m, x2, y1, z2, r, g, b, a); v(buf, m, x1, y1, z2, r, g, b, a);
        // cima
        v(buf, m, x1, y2, z1, r, g, b, a); v(buf, m, x1, y2, z2, r, g, b, a);
        v(buf, m, x2, y2, z2, r, g, b, a); v(buf, m, x2, y2, z1, r, g, b, a);
        // norte
        v(buf, m, x1, y1, z1, r, g, b, a); v(buf, m, x1, y2, z1, r, g, b, a);
        v(buf, m, x2, y2, z1, r, g, b, a); v(buf, m, x2, y1, z1, r, g, b, a);
        // sul
        v(buf, m, x1, y1, z2, r, g, b, a); v(buf, m, x2, y1, z2, r, g, b, a);
        v(buf, m, x2, y2, z2, r, g, b, a); v(buf, m, x1, y2, z2, r, g, b, a);
        // oeste
        v(buf, m, x1, y1, z1, r, g, b, a); v(buf, m, x1, y1, z2, r, g, b, a);
        v(buf, m, x1, y2, z2, r, g, b, a); v(buf, m, x1, y2, z1, r, g, b, a);
        // leste
        v(buf, m, x2, y1, z1, r, g, b, a); v(buf, m, x2, y2, z1, r, g, b, a);
        v(buf, m, x2, y2, z2, r, g, b, a); v(buf, m, x2, y1, z2, r, g, b, a);
    }

    private static void v(BufferBuilder buf, Matrix4f m, float x, float y, float z,
                          float r, float g, float b, float a) {
        buf.vertex(m, x, y, z).color(r, g, b, a).next();
    }

    private static float r(int rgb) { return ((rgb >> 16) & 0xFF) / 255f; }
    private static float g(int rgb) { return ((rgb >> 8) & 0xFF) / 255f; }
    private static float bl(int rgb) { return (rgb & 0xFF) / 255f; }
}
