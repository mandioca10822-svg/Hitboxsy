package com.hitboxvisual;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.MathHelper;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Configuração salva em config/hitboxvisual.json */
public class HitboxConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("hitboxvisual.json");
    private static HitboxConfig instance = new HitboxConfig();

    public boolean enabled = true;          // liga/desliga o mod inteiro
    public boolean showHitboxes = true;     // alternado pela tecla
    public boolean seeThroughWalls = false;
    public boolean showSelf = false;        // própria hitbox em 3ª pessoa

    public boolean players = true;
    public boolean hostile = false;
    public boolean passive = false;
    public boolean otherLiving = false;

    public int normalColor = 0xFF0000;      // fora da mira (RGB)
    public int aimColor = 0x00FF00;         // na mira (RGB)
    public float fillAlpha = 0.20f;         // 0..1
    public float aimFillAlpha = 0.40f;      // 0..1
    public float outlineThickness = 2.0f;   // 0.5..8
    public float maxDistance = 64.0f;       // alcance de render e de mira

    public static HitboxConfig get() {
        return instance;
    }

    public static void load() {
        if (Files.exists(PATH)) {
            try (Reader r = Files.newBufferedReader(PATH)) {
                HitboxConfig c = GSON.fromJson(r, HitboxConfig.class);
                if (c != null) instance = c;
            } catch (IOException | JsonParseException e) {
                System.err.println("[HitboxVisual] Falha ao ler config, usando padrão: " + e);
            }
        }
        instance.clamp();
        save();
    }

    public static void save() {
        instance.clamp();
        try (Writer w = Files.newBufferedWriter(PATH)) {
            GSON.toJson(instance, w);
        } catch (IOException e) {
            System.err.println("[HitboxVisual] Falha ao salvar config: " + e);
        }
    }

    private void clamp() {
        normalColor &= 0xFFFFFF;
        aimColor &= 0xFFFFFF;
        fillAlpha = MathHelper.clamp(fillAlpha, 0f, 1f);
        aimFillAlpha = MathHelper.clamp(aimFillAlpha, 0f, 1f);
        outlineThickness = MathHelper.clamp(outlineThickness, 0.5f, 8f);
        maxDistance = MathHelper.clamp(maxDistance, 4f, 128f);
    }
}
