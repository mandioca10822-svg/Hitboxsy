package com.hitboxvisual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class HitboxVisualClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static KeyBinding configKey;

    @Override
    public void onInitializeClient() {
        HitboxConfig.load();

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hitboxvisual.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "key.categories.hitboxvisual"));
        configKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hitboxvisual.config", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, "key.categories.hitboxvisual"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                HitboxConfig cfg = HitboxConfig.get();
                cfg.showHitboxes = !cfg.showHitboxes;
                HitboxConfig.save();
                if (client.player != null) {
                    client.player.sendMessage(Text.translatable(
                            cfg.showHitboxes ? "hitboxvisual.message.on" : "hitboxvisual.message.off"), true);
                }
            }
            while (configKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new HitboxConfigScreen(null));
                }
            }
        });

        // Depois das entidades e do terreno translúcido: evita problemas de profundidade com água/vidro.
        WorldRenderEvents.AFTER_TRANSLUCENT.register(HitboxRenderer::render);
    }
}
