package com.hitboxvisual;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;

/** Tela de configuração em vanilla (sem Cloth Config / Mod Menu). Abra com a tecla J. */
public class HitboxConfigScreen extends Screen {
    private static final int ROW_H = 22;
    private final Screen parent;
    private int w, x0, y0, gap = 4;

    public HitboxConfigScreen(Screen parent) {
        super(Text.translatable("hitboxvisual.screen.title"));
        this.parent = parent;
    }

    private int px(int i) { return x0 + (i % 3) * (w + gap); }
    private int py(int i) { return y0 + (i / 3) * ROW_H; }

    private void toggle(int i, String key, boolean init, Consumer<Boolean> setter) {
        addDrawableChild(CyclingButtonWidget.onOffBuilder(init).build(px(i), py(i), w, 20,
                Text.translatable("hitboxvisual.option." + key), (btn, v) -> setter.accept(v)));
    }

    private void slider(int i, String key, double min, double max, double init,
                        DoubleFunction<String> fmt, DoubleConsumer setter) {
        addDrawableChild(new ValueSlider(px(i), py(i), w, 20, key, min, max, init, fmt, setter));
    }

    @Override
    protected void init() {
        HitboxConfig c = HitboxConfig.get();
        w = Math.min(150, (width - 16) / 3 - gap);
        x0 = (width - (3 * w + 2 * gap)) / 2;
        y0 = 24;

        toggle(0, "enabled", c.enabled, v -> c.enabled = v);
        toggle(1, "show", c.showHitboxes, v -> c.showHitboxes = v);
        toggle(2, "seethrough", c.seeThroughWalls, v -> c.seeThroughWalls = v);
        toggle(3, "self", c.showSelf, v -> c.showSelf = v);
        toggle(4, "players", c.players, v -> c.players = v);
        toggle(5, "hostile", c.hostile, v -> c.hostile = v);
        toggle(6, "passive", c.passive, v -> c.passive = v);
        toggle(7, "other", c.otherLiving, v -> c.otherLiving = v);

        slider(8, "fill", 0, 1, c.fillAlpha, d -> Math.round(d * 100) + "%", d -> c.fillAlpha = (float) d);
        slider(9, "aimfill", 0, 1, c.aimFillAlpha, d -> Math.round(d * 100) + "%", d -> c.aimFillAlpha = (float) d);
        slider(10, "thickness", 0.5, 8, c.outlineThickness, d -> String.format("%.1f", d), d -> c.outlineThickness = (float) d);
        slider(11, "distance", 4, 128, c.maxDistance, d -> Math.round(d) + "m", d -> c.maxDistance = (float) d);

        int cy = y0 + 4 * ROW_H + 14;
        colorField(px(0), cy, c.normalColor, v -> c.normalColor = v);
        colorField(px(1), cy, c.aimColor, v -> c.aimColor = v);

        addDrawableChild(ButtonWidget.builder(ScreenTexts.DONE, b -> close())
                .dimensions(px(2), cy, w, 20).build());
    }

    private void colorField(int x, int y, int init, Consumer<Integer> setter) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, x, y, w, 20, Text.empty());
        f.setMaxLength(6);
        f.setTextPredicate(s -> s.matches("[0-9a-fA-F]{0,6}"));
        f.setText(String.format("%06X", init & 0xFFFFFF));
        f.setChangedListener(s -> {
            if (s.length() == 6) setter.accept(Integer.parseInt(s, 16));
        });
        addDrawableChild(f);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 8, 0xFFFFFF);
        int cy = y0 + 4 * ROW_H + 14;
        ctx.drawTextWithShadow(textRenderer, Text.translatable("hitboxvisual.option.normalcolor"), px(0), cy - 10, 0xFFAAAAAA);
        ctx.drawTextWithShadow(textRenderer, Text.translatable("hitboxvisual.option.aimcolor"), px(1), cy - 10, 0xFFAAAAAA);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public void removed() {
        HitboxConfig.save();
    }

    private static class ValueSlider extends SliderWidget {
        private final String key;
        private final double min, max;
        private final DoubleFunction<String> fmt;
        private final DoubleConsumer setter;

        ValueSlider(int x, int y, int w, int h, String key, double min, double max, double init,
                    DoubleFunction<String> fmt, DoubleConsumer setter) {
            super(x, y, w, h, Text.empty(), (init - min) / (max - min));
            this.key = key; this.min = min; this.max = max; this.fmt = fmt; this.setter = setter;
            updateMessage();
        }

        private double real() { return min + value * (max - min); }

        @Override
        protected void updateMessage() {
            setMessage(Text.translatable("hitboxvisual.option." + key).append(": " + fmt.apply(real())));
        }

        @Override
        protected void applyValue() {
            setter.accept(real());
        }
    }
}
